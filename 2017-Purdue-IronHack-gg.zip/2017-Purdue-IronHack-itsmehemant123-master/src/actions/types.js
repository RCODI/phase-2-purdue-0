export const FETCH_WEATHER = 'fetch_weather';
