Matt Gillis
2017 Purdue IronHack
-----------------------

01000110 01100101 01100101 01100100  01110100 01101000 01100101  01000010 01100101 01100001 01110011 01110100  
     01010110 01100101 01100111 01100111 01101001 01100101 01110011                                                                                              

BS Clean template: http://www.free-css.com/free-css-templates/page210/bs-clean

Bottom-Black-Background.jpg
https://cdn.pixabay.com/photo/2015/11/28/06/52/background-1066859_960_720.jpg

overlaymap.png
http://userpages.umbc.edu/~henrym1/Maps/images/overlaymap.png

Sky.jpg
http://wallpapersafari.com/w/k5ZTpv/

Grayscale Yellow Map Style
https://snazzymaps.com/style/6793/grayscale-yellow


Edit for submission 2:  sry, busy week and all. It's just this line in the readme being added. We'll see what happens next time.
