In this first phase of submition, I have created a google map on the website with google API, which shows some of the hard coded stores I found that sell produce in the greater lafayette area.

This submition also includes, a template what is going to go where. Such as the columns for different graphs.

*currently, all my css, js and html is all in file, but in the future I will split them up.