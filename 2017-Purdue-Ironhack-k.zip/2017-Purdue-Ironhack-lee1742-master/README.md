Welcome come to Jiyoon's Ironhacks!

# Where to find the cheapest and most fresh vegetables?

* Dataset list
  - Climate Data Online (CDO) - Climate Data Online (https://www.ncdc.noaa.gov/cdo-web/webservices/v2)
      > Historical data will be used to predict future prices and freshness trends.
  - Food Poisoning Trend - Google Trends (https://trends.google.com/trends/)
      > Recent food poisoning trends can be used to predict a freshness of vegetables.
  - National Agricultural Statistics Sevice - QuickStats API (https://quickstats.nass.usda.gov/api)
      > Supply of vegetables can affect prices of vegetables.

* Technologies
  - node.js
      > To develop webpages
  - d3.js
      > To visualize matkets
  - Google map API
      > To search a list of nearby markets

* References
  - Waugh, F. V. (1928). Quality factors influencing vegetable prices. Journal of farm economics, 10(2), 185-196.
