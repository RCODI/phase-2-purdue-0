# Welcome to Ironhacks!

My application is designed to make it easier to buy vegetables, specifically for people on lower incomes.
