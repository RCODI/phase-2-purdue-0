# Dev - [Freshtables](http://web.ics.purdue.edu/~nabraham/2017-Purdue-IronHack-NTAbraham/dev/index)


Ive been working in the dev folder. In order to open upload my files and view my results please open the dev folder and open the index.html file.

## App Implementation

There is filler words in many places inorder to get the right consistency in places.
I intend to make an app where using the CUESA http://www.cuesa.org/eat-seasonally/charts/vegetables website and the data.gov vegetable prices https://www.ers.usda.gov/data-products/fruit-and-vegetable-prices/ I have created my own dataset in order to make my app.
I am still yet to implement it in due time. I have created little bit of the dataset for a couple vegetables in a [vegetables.csv]((http://web.ics.purdue.edu/~nabraham/2017-Purdue-IronHack-NTAbraham/dev/vegetables.csv) which you can view.

Ive also used a bootstrap template that which is available online and Ive tweeked it to give it some of the veggie touch([Start Bootstrap](http://startbootstrap.com/) - [Business Casual](http://startbootstrap.com/template-overviews/business-casual/))