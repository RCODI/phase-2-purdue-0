# Welcome come to Ironhacks!

1. Name of the Application - Freshness Amplified! <br/>
2. Keywords- Distance, Mode of transportation (walk, bicycle, city bus or car), price  <br/>
3. I have used the  NOAA's National Climatic Data Center data set- Climate data online<br/>
I was able to fetch the datacategories for a given set of locations. As of now I have displayed the extracted results on the Console.
4. The main objective of this project is to build a website that guides the users to make a thoughtful decision over the choice market they would visit in order to buy the most fresh vegetables available in their area with the best possible deal. <br/>
5. I have just used HTML, CSS and Java script, jQuery as of now.<br/>
6. I have tesed my application on the Google Chrome browser.<br/>

Structured Description: <br/>

Map View:<br/>
 i) Yes, I have used google API to display the basic map with center at Purdue University, West Lafayette <br/>
 ii) Yes, I have added markers for the location of markets<br/>
 iv) Yes, I have information windows to show the details of specific markets on the map. As of now I have just the market's name in the information window, however, my next immediate task is to add details to it.<br/>
<br/>
 


